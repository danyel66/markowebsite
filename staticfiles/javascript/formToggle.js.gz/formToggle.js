document.querySelector(".form__sign-up-anchor").addEventListener('click',()=>{
    document.querySelector(".form").style.display="none";
    document.querySelector(".form2").style.display="block";

});

document.querySelector(".form2__sign-up-anchor").addEventListener('click',()=>{
    document.querySelector(".form2").style.display="none";
    document.querySelector(".form").style.display="block";

});
